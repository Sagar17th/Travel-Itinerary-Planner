// ===============================
// plan-script.js (V3 - robust submit + day-by-day generator)
// ===============================

document.addEventListener("DOMContentLoaded", function () {
  console.log("✅ plan-script.js loaded");

  // Elements (guard lookups)
  const personalForm = byId("personal-form");
  const travelForm   = byId("travel-form");
  const nextBtn      = byId("next-to-trip");
  const backBtn      = byId("back-to-personal");
  const itineraryOut = byId("itinerary-output");
  const personalSec  = byId("personal-info");
  const tripSec      = byId("trip-details");
  const itinContent  = byId("itinerary-content");
  const travelerSum  = byId("traveler-summary");

  // Ensure required nodes exist
  if (!personalForm || !travelForm || !nextBtn || !backBtn || !itinContent) {
    console.error("❌ Missing required DOM elements. Check IDs in plan.html.");
    return;
  }

  // Populate states (requires states-data.js loaded BEFORE this)
  try {
    populateStates();
  } catch (e) {
    console.warn("⚠️ Could not populate states. Is states-data.js loaded first?", e);
  }

  // --- Step 1 -> Step 2 ---
  nextBtn.addEventListener("click", () => {
    // Use native HTML5 validation for Step 1
    if (!personalForm.checkValidity()) {
      personalForm.reportValidity();
      return;
    }
    personalSec.classList.add("hidden");
    tripSec.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
    console.log("➡️ Moved to Step 2");
  });

  // --- Step 2 -> Step 1 ---
  backBtn.addEventListener("click", () => {
    tripSec.classList.add("hidden");
    personalSec.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
    console.log("⬅️ Back to Step 1");
  });

  // --- Generate itinerary on FORM SUBMIT (more reliable than button click) ---
  travelForm.addEventListener("submit", (e) => {
    e.preventDefault();

    // Validate Step 2 form fields
    if (!travelForm.checkValidity()) {
      travelForm.reportValidity();
      return;
    }

    // Collect both forms
    const personalData = formToObj(personalForm);
    const tripData     = formToObj(travelForm);
    const data         = { ...personalData, ...tripData };

    // Normalize / defaults
    data.duration = clampInt(data.duration, 7, 3, 30); // default 7, min 3, max 30
    data.budget = data.budget || "mid-range";
    data.travelStyle = data.travelStyle || data["travelStyle"] || byId("travel-style")?.value || "mixed";

    console.log("🧭 Generating itinerary with:", data);

    // Guard: indiaTravelData must exist
    if (typeof indiaTravelData === "undefined" || !indiaTravelData.states) {
      alert("⚠️ Travel data not loaded. Ensure states-data.js is included before plan-script.js.");
      return;
    }

    // Generate HTML itinerary
    const html = generateItineraryContent(data);

    // Display
    itinContent.innerHTML = html;

    // Summary
    travelerSum.classList.remove("hidden");
    travelerSum.innerHTML = `
      <h3>👤 Traveler Summary</h3>
      <div class="traveler-details">
        <div><strong>Name:</strong> ${escapeHtml(data.fullName || "N/A")}</div>
        <div><strong>Age:</strong> ${escapeHtml(data.age || "")}</div>
        <div><strong>State:</strong> ${escapeHtml(data.state || "")}</div>
        <div><strong>Duration:</strong> ${escapeHtml(String(data.duration))} days</div>
        <div><strong>Budget:</strong> ${escapeHtml(data.budget)}</div>
        <div><strong>Style:</strong> ${escapeHtml(data.travelStyle)}</div>
      </div>
    `;

    // Show Step 3
    tripSec.classList.add("hidden");
    itineraryOut.classList.remove("hidden");
    window.scrollTo({ top: 0, behavior: "smooth" });
    console.log("🗺️ Itinerary generated and shown (Step 3)");
  });
});

// ===============================
// Populate State Dropdown
// ===============================
function populateStates() {
  const sel = byId("state");
  if (!sel) return;
  if (typeof indiaTravelData === "undefined" || !indiaTravelData.states) return;

  // Clear (keep first placeholder)
  while (sel.options.length > 1) sel.remove(1);

  indiaTravelData.states.forEach((s) => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.name;
    sel.appendChild(opt);
  });
  console.log("✅ States populated:", indiaTravelData.states.length);
}

// ===============================
// Generate Itinerary (day-by-day)
// ===============================
function generateItineraryContent(data) {
  const stateInfo = indiaTravelData.states.find((s) => s.id === data.state);
  if (!stateInfo) {
    return `<div class="itinerary-header"><h3>Plan for ${escapeHtml(data.state)}</h3><p>${escapeHtml(
      String(data.duration)
    )} days • ${escapeHtml(data.travelStyle)}</p></div>`;
  }

  const styleActs  = (indiaTravelData.activityRecommendations.byTravelStyle[data.travelStyle] || []);
  const seasonActs = (indiaTravelData.activityRecommendations.bySeason[data.season] || []);
  const highlights = (stateInfo.mustVisit || []);
  const combined   = unique([...highlights, ...styleActs, ...seasonActs]);

  const days = [];
  const D = clampInt(data.duration, 7, 3, 30);

  for (let d = 1; d <= D; d++) {
    const items = pick(combined, 3);
    days.push({
      day: d,
      title: `Day ${d}: Discover ${stateInfo.name}`,
      items
    });
  }

  // Header
  let html = `
    <div class="itinerary-header">
      <h3>🌍 ${escapeHtml(stateInfo.name)} - ${escapeHtml(stateInfo.description)}</h3>
      <p class="itinerary-meta">
        Season: ${escapeHtml(capitalize(data.season || "—"))} • Style: ${escapeHtml(capitalize(data.travelStyle))} • Days: ${D}
      </p>
      ${data.cities ? `<p class="cities-tag">📍 Cities: ${escapeHtml(data.cities)}</p>` : ""}
    </div>
  `;

  // Days
  days.forEach((d) => {
    html += `
      <div class="itinerary-day">
        <div class="itinerary-day-header">
          <h4 class="day-title">${escapeHtml(d.title)}</h4>
          <span class="day-date">Day ${d.day}</span>
        </div>
        <ul class="activity-list">
          ${d.items.map((a) => activityRow(a, data.travelStyle)).join("")}
        </ul>
      </div>
    `;
  });

  // Budget notes + practical info
  const budgetNotes = {
    "budget":   "Cozy homestays, local eateries, and smart transport choices keep costs low.",
    "mid-range":"Comfortable hotels, guided highlights, balanced dining and transit.",
    "luxury":   "Premium stays, private transfers, exclusive experiences, and fine dining."
  };

  html += `
    <div class="budget-note"><p>${escapeHtml(budgetNotes[data.budget] || "")}</p></div>

    <div class="practical-info">
      <h4>💡 Practical Tips</h4>
      <div class="info-grid">
        <div class="info-item"><strong>Budget Type:</strong> ${escapeHtml(capitalize(data.budget))}</div>
        <div class="info-item"><strong>Recommended Transport:</strong> ${escapeHtml((indiaTravelData.transportation[data.budget] || []).join(", "))}</div>
        <div class="info-item"><strong>Local Cuisine:</strong> ${escapeHtml((stateInfo.localCuisine || []).slice(0,3).join(", "))}</div>
      </div>
    </div>
  `;

  const tips = [
    "Visit major attractions early to beat crowds.",
    "Carry cash for small vendors in local markets.",
    "Hydrate well and use sunscreen on outdoor days.",
    "Pre-book popular tickets to avoid queues.",
    "Respect local customs at religious places."
  ];
  html += `
    <div class="daily-tip"><strong>💡 Travel Tip:</strong> ${escapeHtml(tips[Math.floor(Math.random()*tips.length)])}</div>
  `;

  return html;
}

function activityRow(activity, style) {
  return `
    <li class="activity-item">
      <div class="activity-time">🕒 ${getRandomTime()}</div>
      <div class="activity-details">
        <div class="activity-title">${escapeHtml(activity)}</div>
        <div class="activity-description">
          ${escapeHtml(`Experience ${activity.toLowerCase()} — great for ${style} travelers.`)}
        </div>
      </div>
    </li>
  `;
}

// ===============================
// Helpers
// ===============================
function byId(id) { return document.getElementById(id); }

function formToObj(formEl) {
  return Object.fromEntries(new FormData(formEl).entries());
}

function clampInt(val, def, min, max) {
  let n = parseInt(val);
  if (Number.isNaN(n)) n = def;
  n = Math.max(min, Math.min(max, n));
  return n;
}

function unique(arr) {
  return [...new Set(arr.filter(Boolean))];
}

function pick(arr, count) {
  // non-mutating shuffle + slice
  return [...arr].sort(() => Math.random() - 0.5).slice(0, count);
}

function getRandomTime() {
  const times = ["8:00 AM", "10:00 AM", "12:30 PM", "2:30 PM", "4:30 PM", "7:00 PM"];
  return times[Math.floor(Math.random() * times.length)];
}

function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

function escapeHtml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
