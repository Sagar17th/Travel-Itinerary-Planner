// frontend/states-data.js - Complete Indian states travel data
const indiaTravelData = {
    states: [
        {
            id: 'delhi',
            name: 'Delhi',
            type: 'union-territory',
            bestSeason: ['winter'],
            description: 'The capital city blending ancient history with modern development',
            specialties: ['Historical Monuments', 'Street Food', 'Shopping'],
            cities: ['New Delhi', 'Old Delhi'],
            culturalHighlights: ['Mughal Architecture', 'Street Markets', 'Diverse Cuisine'],
            mustVisit: ['Red Fort', 'Qutub Minar', 'India Gate', 'Lotus Temple'],
            localCuisine: ['Chaat', 'Butter Chicken', 'Parathas', 'Chole Bhature'],
            festivals: ['Republic Day', 'Diwali', 'Holi'],
            accommodation: {
                budget: ['Paharganj', 'Majnu Ka Tila'],
                midRange: ['Connaught Place', 'Karol Bagh'],
                luxury: ['Chanakyapuri', 'Saket']
            }
        },
        {
            id: 'maharashtra',
            name: 'Maharashtra',
            type: 'state',
            bestSeason: ['winter'],
            description: 'Land of vibrant cities, ancient caves, and beautiful beaches',
            specialties: ['Bollywood', 'Historical Caves', 'Beaches'],
            cities: ['Mumbai', 'Pune', 'Aurangabad', 'Nasik'],
            culturalHighlights: ['Marathi Culture', 'Film Industry', 'Colonial Architecture'],
            mustVisit: ['Gateway of India', 'Ajanta-Ellora Caves', 'Shaniwar Wada', 'Marine Drive'],
            localCuisine: ['Vada Pav', 'Pav Bhaji', 'Misal Pav', 'Puran Poli'],
            festivals: ['Ganesh Chaturthi', 'Gudi Padwa', 'Mumbai Film Festival'],
            accommodation: {
                budget: ['Colaba', 'Andheri'],
                midRange: ['Bandra', 'Koregaon Park'],
                luxury: ['Marine Drive', 'Khandala']
            }
        },
        {
            id: 'rajasthan',
            name: 'Rajasthan',
            type: 'state',
            bestSeason: ['winter'],
            description: 'The land of kings with majestic forts and desert landscapes',
            specialties: ['Royal Forts', 'Desert Safari', 'Folk Culture'],
            cities: ['Jaipur', 'Udaipur', 'Jodhpur', 'Jaisalmer'],
            culturalHighlights: ['Rajput Culture', 'Folk Music', 'Traditional Crafts'],
            mustVisit: ['Amber Fort', 'City Palace Udaipur', 'Mehrangarh Fort', 'Thar Desert'],
            localCuisine: ['Dal Baati Churma', 'Laal Maas', 'Gatte Ki Sabzi', 'Mirchi Bada'],
            festivals: ['Pushkar Fair', 'Desert Festival', 'Teej'],
            accommodation: {
                budget: ['Heritage Havelis', 'Guest Houses'],
                midRange: ['Boutique Hotels', 'Palace Stays'],
                luxury: ['Royal Palaces', 'Desert Camps']
            }
        },
        {
            id: 'goa',
            name: 'Goa',
            type: 'state',
            bestSeason: ['winter'],
            description: 'Tropical paradise with beaches, Portuguese heritage, and vibrant nightlife',
            specialties: ['Beaches', 'Portuguese Architecture', 'Seafood'],
            cities: ['Panaji', 'Vasco da Gama', 'Mapusa', 'Margao'],
            culturalHighlights: ['Portuguese Influence', 'Beach Culture', 'Carnival'],
            mustVisit: ['Calangute Beach', 'Basilica of Bom Jesus', 'Dudhsagar Falls', 'Anjuna Flea Market'],
            localCuisine: ['Fish Curry Rice', 'Pork Vindaloo', 'Bebinca', 'Feni'],
            festivals: ['Carnival', 'Christmas', 'Shigmo'],
            accommodation: {
                budget: ['Beach Huts', 'Hostels'],
                midRange: ['Beach Resorts', 'Boutique Stays'],
                luxury: ['Luxury Villas', '5-Star Resorts']
            }
        },
        {
            id: 'kerala',
            name: 'Kerala',
            type: 'state',
            bestSeason: ['winter'],
            description: 'God\'s Own Country with backwaters, hills, and Ayurvedic traditions',
            specialties: ['Backwaters', 'Ayurveda', 'Hill Stations'],
            cities: ['Kochi', 'Thiruvananthapuram', 'Kozhikode', 'Munnar'],
            culturalHighlights: ['Kathakali', 'Theyyam', 'Traditional Martial Arts'],
            mustVisit: ['Alleppey Backwaters', 'Munnar Tea Gardens', 'Kovalam Beach', 'Periyar Wildlife Sanctuary'],
            localCuisine: ['Appam with Stew', 'Puttu with Kadala', 'Karimeen Pollichathu', 'Sadya'],
            festivals: ['Onam', 'Vishu', 'Thrissur Pooram'],
            accommodation: {
                budget: ['Homestays', 'Houseboats'],
                midRange: ['Resorts', 'Ayurvedic Centers'],
                luxury: ['Luxury Houseboats', 'Hill Resort']
            }
        },
        {
            id: 'tamil-nadu',
            name: 'Tamil Nadu',
            type: 'state',
            bestSeason: ['winter'],
            description: 'Land of magnificent temples and rich Dravidian culture',
            specialties: ['Temple Architecture', 'Classical Dance', 'Filter Coffee'],
            cities: ['Chennai', 'Madurai', 'Coimbatore', 'Ooty'],
            culturalHighlights: ['Tamil Culture', 'Bharatanatyam', 'Temple Festivals'],
            mustVisit: ['Meenakshi Temple', 'Brihadeeswarar Temple', 'Ooty Hill Station', 'Marina Beach'],
            localCuisine: ['Dosa', 'Idli', 'Pongal', 'Chettinad Cuisine'],
            festivals: ['Pongal', 'Jallikattu', 'Temple Car Festivals'],
            accommodation: {
                budget: ['Temple Towns', 'Budget Hotels'],
                midRange: ['Business Hotels', 'Heritage Properties'],
                luxury: ['Luxury Resorts', 'Palace Hotels']
            }
        },
        {
            id: 'uttarakhand',
            name: 'Uttarakhand',
            type: 'state',
            bestSeason: ['summer', 'winter'],
            description: 'Devbhumi - Land of Gods with Himalayan peaks and spiritual destinations',
            specialties: ['Himalayan Treks', 'Spiritual Sites', 'Adventure Sports'],
            cities: ['Dehradun', 'Haridwar', 'Rishikesh', 'Nainital'],
            culturalHighlights: ['Garhwali Culture', 'Yoga Capital', 'Char Dham Yatra'],
            mustVisit: ['Valley of Flowers', 'Kedarnath Temple', 'Rishikesh Ganga Aarti', 'Mussoorie'],
            localCuisine: ['Kafuli', 'Bhatt Ki Churdkani', 'Gahat Ki Dal', 'Bal Mithai'],
            festivals: ['Maha Kumbh Mela', 'Ganga Dussehra', 'Phool Dei'],
            accommodation: {
                budget: ['Ashrams', 'Guest Houses'],
                midRange: ['Resorts', 'Yoga Centers'],
                luxury: ['Luxury Retreats', 'Mountain Resorts']
            }
        },
        {
            id: 'himachal-pradesh',
            name: 'Himachal Pradesh',
            type: 'state',
            bestSeason: ['summer', 'winter'],
            description: 'Mountain state with snow-capped peaks and picturesque valleys',
            specialties: ['Snow Sports', 'Apple Orchards', 'Trekking'],
            cities: ['Shimla', 'Manali', 'Dharamshala', 'Dalhousie'],
            culturalHighlights: ['Tibetan Culture', 'Himachali Folk', 'British Heritage'],
            mustVisit: ['Rohtang Pass', 'Mall Road Shimla', 'McLeod Ganj', 'Spiti Valley'],
            localCuisine: ['Siddu', 'Dham', 'Thukpa', 'Babru'],
            festivals: ['Kullu Dussehra', 'Losar', 'Shivratri Fair'],
            accommodation: {
                budget: ['Hostels', 'Homestays'],
                midRange: ['Hotels', 'Cottages'],
                luxury: ['Luxury Resorts', 'Heritage Properties']
            }
        },
        {
            id: 'karnataka',
            name: 'Karnataka',
            type: 'state',
            bestSeason: ['winter'],
            description: 'Diverse state with ancient ruins, tech cities, and coffee plantations',
            specialties: ['Ancient Architecture', 'Coffee Estates', 'Silk Sarees'],
            cities: ['Bangalore', 'Mysore', 'Hampi', 'Mangalore'],
            culturalHighlights: ['Kannada Culture', 'Classical Music', 'Yakshagana'],
            mustVisit: ['Hampi Ruins', 'Mysore Palace', 'Coorg Coffee Plantations', 'Gokarna Beaches'],
            localCuisine: ['Bisi Bele Bath', 'Mysore Pak', 'Neer Dosa', 'Coorg Pandi Curry'],
            festivals: ['Mysore Dasara', 'Ugadi', 'Hampi Festival'],
            accommodation: {
                budget: ['Hostels', 'Lodges'],
                midRange: ['Hotels', 'Plantation Stays'],
                luxury: ['Luxury Resorts', 'Palace Hotels']
            }
        },
        {
            id: 'west-bengal',
            name: 'West Bengal',
            type: 'state',
            bestSeason: ['winter'],
            description: 'Cultural capital with literary heritage and diverse landscapes',
            specialties: ['Durga Puja', 'Tea Gardens', 'Sunderbans'],
            cities: ['Kolkata', 'Darjeeling', 'Durgapur', 'Siliguri'],
            culturalHighlights: ['Bengali Renaissance', 'Rabindra Sangeet', 'Art & Literature'],
            mustVisit: ['Victoria Memorial', 'Darjeeling Tea Gardens', 'Sunderbans', 'Howrah Bridge'],
            localCuisine: ['Macher Jhol', 'Rosogolla', 'Misti Doi', 'Kathi Rolls'],
            festivals: ['Durga Puja', 'Poila Boishakh', 'Book Fair'],
            accommodation: {
                budget: ['Guest Houses', 'Budget Hotels'],
                midRange: ['Heritage Properties', 'Hotels'],
                luxury: ['Luxury Hotels', 'Tea Estate Bungalows']
            }
        },
        {
            id: 'uttar-pradesh',
            name: 'Uttar Pradesh',
            type: 'state',
            bestSeason: ['winter'],
            description: 'Heart of India with spiritual significance and historical monuments',
            specialties: ['Spiritual Tourism', 'Mughal Architecture', 'Ganga River'],
            cities: ['Varanasi', 'Agra', 'Lucknow', 'Allahabad'],
            culturalHighlights: ['Ganga Aarti', 'Awadhi Culture', 'Classical Music'],
            mustVisit: ['Taj Mahal', 'Varanasi Ghats', 'Lucknow Residency', 'Sarnath'],
            localCuisine: ['Awadhi Biryani', 'Kachori Sabzi', 'Chaat', 'Malai Makhan'],
            festivals: ['Kumbh Mela', 'Diwali', 'Holi'],
            accommodation: {
                budget: ['Dharamshalas', 'Guest Houses'],
                midRange: ['Hotels', 'Heritage Properties'],
                luxury: ['Luxury Hotels', 'Palace Stays']
            }
        },
        {
            id: 'gujarat',
            name: 'Gujarat',
            type: 'state',
            bestSeason: ['winter'],
            description: 'Land of vibrant culture, business hubs, and architectural wonders',
            specialties: ['Business Tourism', 'Temple Architecture', 'Wildlife Sanctuaries'],
            cities: ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot'],
            culturalHighlights: ['Garba Dance', 'Business Culture', 'Stepwell Architecture'],
            mustVisit: ['Sabarmati Ashram', 'Rann of Kutch', 'Somnath Temple', 'Gir National Park'],
            localCuisine: ['Dhokla', 'Thepla', 'Khandvi', 'Fafda'],
            festivals: ['Navratri', 'Uttarayan', 'Rann Utsav'],
            accommodation: {
                budget: ['Business Hotels', 'Guest Houses'],
                midRange: ['Comfort Hotels', 'Heritage Stays'],
                luxury: ['Luxury Hotels', 'Desert Camps']
            }
        },
        {
            id: 'punjab',
            name: 'Punjab',
            type: 'state',
            bestSeason: ['winter'],
            description: 'Land of vibrant culture, agriculture, and spiritual sites',
            specialties: ['Golden Temple', 'Agriculture Tourism', 'Folk Culture'],
            cities: ['Amritsar', 'Chandigarh', 'Ludhiana', 'Jalandhar'],
            culturalHighlights: ['Sikh Culture', 'Bhangra Dance', 'Agricultural Heritage'],
            mustVisit: ['Golden Temple', 'Wagah Border', 'Jallianwala Bagh', 'Anandpur Sahib'],
            localCuisine: ['Butter Chicken', 'Sarson Ka Saag', 'Makki Ki Roti', 'Lassi'],
            festivals: ['Lohri', 'Baisakhi', 'Gurpurab'],
            accommodation: {
                budget: ['Gurudwara Stay', 'Budget Hotels'],
                midRange: ['Comfort Hotels', 'Business Stays'],
                luxury: ['Luxury Hotels', 'Resorts']
            }
        }
    ],

    // Activity recommendations based on traveler profiles
    activityRecommendations: {
        byAge: {
            '12-25': ['Adventure Sports', 'Night Markets', 'Hostel Stays', 'Budget Travel', 'Photography Tours'],
            '26-40': ['Cultural Sites', 'Food Tours', 'Moderate Adventure', 'Comfortable Stays', 'Local Workshops'],
            '41-60': ['Heritage Sites', 'Luxury Stays', 'Wellness Activities', 'Guided Tours', 'Culinary Classes'],
            '61+': ['Religious Sites', 'Comfortable Transportation', 'Relaxed Pace', 'Accessible Locations', 'Cultural Shows']
        },
        
        byGender: {
            'female': ['Women-Only Accommodations', 'Safe Transportation', 'Group Tours', 'Well-lit Areas', 'Shopping Districts'],
            'male': ['All Adventure Activities', 'Flexible Itineraries', 'Various Accommodation Types', 'Night Activities'],
            'other': ['Inclusive Spaces', 'Flexible Options', 'Respectful Environments', 'Private Tours']
        },
        
        byTravelStyle: {
            'cultural': ['Museum Visits', 'Historical Sites', 'Local Festivals', 'Traditional Performances', 'Art Galleries'],
            'adventure': ['Trekking', 'Water Sports', 'Wildlife Safaris', 'Mountain Activities', 'Camping'],
            'spiritual': ['Temple Visits', 'Meditation Centers', 'Yoga Retreats', 'Pilgrimage Sites', 'Ashram Stays'],
            'culinary': ['Food Walks', 'Cooking Classes', 'Local Markets', 'Restaurant Hopping', 'Food Festivals'],
            'beach': ['Beach Activities', 'Water Sports', 'Seafood Dining', 'Relaxation', 'Sunset Views'],
            'mixed': ['Combination of All', 'Flexible Itineraries', 'Varied Experiences', 'Local Interactions']
        },
        
        bySeason: {
            'summer': ['Hill Stations', 'Early Morning Activities', 'Indoor Attractions', 'Water Activities', 'Air-conditioned Transport'],
            'monsoon': ['Indoor Cultural Sites', 'Museum Visits', 'Spa Treatments', 'Local Cuisine Exploration', 'Shopping Malls'],
            'winter': ['Desert Safaris', 'Beach Activities', 'Outdoor Festivals', 'Adventure Sports', 'Bonfire Nights']
        }
    },

    // Transportation recommendations
    transportation: {
        budget: ['Local Buses', 'Auto Rickshaws', 'Shared Taxis', 'Metro', 'Cycle Rickshaws'],
        midRange: ['Private Taxis', 'Car Rentals', 'Domestic Flights', 'AC Trains', 'App-based Cabs'],
        luxury: ['Private Car with Driver', 'Business Class Flights', 'Luxury Trains', 'Helicopter Tours', 'Luxury Coaches']
    },

    // Safety tips for different traveler profiles
    safetyTips: {
        general: [
            'Keep emergency numbers handy',
            'Carry copies of important documents',
            'Stay hydrated and eat at clean establishments',
            'Respect local customs and dress modestly',
            'Keep valuables in hotel safe'
        ],
        female: [
            'Avoid traveling alone at night',
            'Use registered taxi services',
            'Dress conservatively in religious places',
            'Stay in well-reviewed accommodations',
            'Share itinerary with family/friends'
        ],
        senior: [
            'Carry necessary medications',
            'Choose accessible accommodations',
            'Take regular breaks',
            'Have emergency contacts readily available',
            'Travel with companions if possible'
        ],
        family: [
            'Choose family-friendly accommodations',
            'Carry snacks and water for children',
            'Plan child-friendly activities',
            'Keep first-aid kit handy',
            'Research medical facilities in advance'
        ]
    }
};