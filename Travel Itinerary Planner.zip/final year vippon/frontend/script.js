// script.js - Home Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    console.log('WanderPlan AI Home Page loaded');
    
    // Initialize feature card animations
    initFeatureCardAnimations();
    
    // Add smooth scrolling for internal links
    initSmoothScrolling();
    
    // Add any other home page specific interactions
});

/**
 * Initialize animations for feature cards
 */
function initFeatureCardAnimations() {
    const featureCards = document.querySelectorAll('.feature-card');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                entry.target.style.transition = 'all 0.6s ease';
            }
        });
    }, {
        threshold: 0.1
    });

    // Set initial state and observe each card
    featureCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(30px)';
        observer.observe(card);
    });
}

/**
 * Initialize smooth scrolling for anchor links
 */
function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

/**
 * Utility function to handle CTA button interactions
 */
function initCTAbutton() {
    const ctaButton = document.querySelector('.cta-button');
    if (ctaButton) {
        ctaButton.addEventListener('click', function(e) {
            // Add any CTA button specific interactions
            console.log('CTA button clicked - navigating to plan page');
        });
    }
}

/**
 * Initialize all home page functionality
 */
function initHomePage() {
    initFeatureCardAnimations();
    initSmoothScrolling();
    initCTAbutton();
    
    console.log('Home page initialized successfully');
}

// Initialize when DOM is fully loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initHomePage);
} else {
    initHomePage();
}