const express = require('express');
const Traveler = require('../models/traveler');
const router = express.Router();

// Create a new traveler
router.post('/', async (req, res) => {
    try {
        const travelerData = req.body;
        
        // Validate required fields
        const requiredFields = ['fullName', 'age', 'gender', 'email', 'state', 'season', 'duration', 'budget', 'travelStyle'];
        for (const field of requiredFields) {
            if (!travelerData[field]) {
                return res.status(400).json({
                    error: `Missing required field: ${field}`
                });
            }
        }

        // Check if email already exists
        const existingTraveler = await Traveler.findOne({ email: travelerData.email });
        if (existingTraveler) {
            return res.status(409).json({
                error: 'Traveler with this email already exists'
            });
        }

        const traveler = new Traveler(travelerData);
        const savedTraveler = await traveler.save();

        res.status(201).json({
            message: 'Traveler created successfully',
            traveler: {
                id: savedTraveler._id,
                fullName: savedTraveler.fullName,
                email: savedTraveler.email,
                state: savedTraveler.state
            }
        });
    } catch (error) {
        console.error('Error creating traveler:', error);
        
        if (error.name === 'ValidationError') {
            const errors = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({
                error: 'Validation failed',
                details: errors
            });
        }

        res.status(500).json({
            error: 'Failed to create traveler',
            message: error.message
        });
    }
});

// Get all travelers (with pagination)
router.get('/', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const travelers = await Traveler.find()
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .select('-__v');

        const total = await Traveler.countDocuments();

        res.json({
            travelers,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        console.error('Error fetching travelers:', error);
        res.status(500).json({
            error: 'Failed to fetch travelers',
            message: error.message
        });
    }
});

// Get traveler by ID
router.get('/:id', async (req, res) => {
    try {
        const traveler = await Traveler.findById(req.params.id).select('-__v');
        
        if (!traveler) {
            return res.status(404).json({
                error: 'Traveler not found'
            });
        }

        res.json(traveler);
    } catch (error) {
        console.error('Error fetching traveler:', error);
        
        if (error.name === 'CastError') {
            return res.status(400).json({
                error: 'Invalid traveler ID'
            });
        }

        res.status(500).json({
            error: 'Failed to fetch traveler',
            message: error.message
        });
    }
});

// Get traveler by email
router.get('/email/:email', async (req, res) => {
    try {
        const traveler = await Traveler.findOne({ email: req.params.email }).select('-__v');
        
        if (!traveler) {
            return res.status(404).json({
                error: 'Traveler not found'
            });
        }

        res.json(traveler);
    } catch (error) {
        console.error('Error fetching traveler by email:', error);
        res.status(500).json({
            error: 'Failed to fetch traveler',
            message: error.message
        });
    }
});

// Get statistics
router.get('/stats/summary', async (req, res) => {
    try {
        const stats = await Traveler.getStatistics();
        res.json(stats);
    } catch (error) {
        console.error('Error fetching statistics:', error);
        res.status(500).json({
            error: 'Failed to fetch statistics',
            message: error.message
        });
    }
});

// Update traveler
router.put('/:id', async (req, res) => {
    try {
        const traveler = await Traveler.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        ).select('-__v');

        if (!traveler) {
            return res.status(404).json({
                error: 'Traveler not found'
            });
        }

        res.json({
            message: 'Traveler updated successfully',
            traveler
        });
    } catch (error) {
        console.error('Error updating traveler:', error);
        
        if (error.name === 'ValidationError') {
            const errors = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({
                error: 'Validation failed',
                details: errors
            });
        }

        res.status(500).json({
            error: 'Failed to update traveler',
            message: error.message
        });
    }
});

// Delete traveler
router.delete('/:id', async (req, res) => {
    try {
        const traveler = await Traveler.findByIdAndDelete(req.params.id);
        
        if (!traveler) {
            return res.status(404).json({
                error: 'Traveler not found'
            });
        }

        res.json({
            message: 'Traveler deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting traveler:', error);
        res.status(500).json({
            error: 'Failed to delete traveler',
            message: error.message
        });
    }
});

module.exports = router;