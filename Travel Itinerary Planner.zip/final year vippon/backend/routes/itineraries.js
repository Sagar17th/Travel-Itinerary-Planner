const express = require('express');
const Itinerary = require('../models/Itinerary');
const Traveler = require('../models/traveler');
const router = express.Router();

// Create a new itinerary
router.post('/', async (req, res) => {
    try {
        const itineraryData = req.body;
        
        // Validate required fields
        const requiredFields = ['travelerId', 'state', 'duration', 'travelStyle', 'budget', 'itineraryContent'];
        for (const field of requiredFields) {
            if (!itineraryData[field]) {
                return res.status(400).json({
                    error: `Missing required field: ${field}`
                });
            }
        }

        // Verify traveler exists
        const traveler = await Traveler.findById(itineraryData.travelerId);
        if (!traveler) {
            return res.status(404).json({
                error: 'Traveler not found'
            });
        }

        const itinerary = new Itinerary(itineraryData);
        const savedItinerary = await itinerary.save();

        res.status(201).json({
            message: 'Itinerary created successfully',
            itinerary: {
                id: savedItinerary._id,
                travelerId: savedItinerary.travelerId,
                state: savedItinerary.state,
                duration: savedItinerary.duration
            }
        });
    } catch (error) {
        console.error('Error creating itinerary:', error);
        
        if (error.name === 'ValidationError') {
            const errors = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({
                error: 'Validation failed',
                details: errors
            });
        }

        res.status(500).json({
            error: 'Failed to create itinerary',
            message: error.message
        });
    }
});

// Get all itineraries (with pagination)
router.get('/', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const skip = (page - 1) * limit;

        const itineraries = await Itinerary.find()
            .populate('travelerId', 'fullName email age gender')
            .sort({ generatedAt: -1 })
            .skip(skip)
            .limit(limit)
            .select('-__v');

        const total = await Itinerary.countDocuments();

        res.json({
            itineraries,
            pagination: {
                page,
                limit,
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        console.error('Error fetching itineraries:', error);
        res.status(500).json({
            error: 'Failed to fetch itineraries',
            message: error.message
        });
    }
});

// Get itineraries by traveler ID
router.get('/traveler/:travelerId', async (req, res) => {
    try {
        const itineraries = await Itinerary.find({ travelerId: req.params.travelerId })
            .sort({ generatedAt: -1 })
            .select('-__v');

        res.json(itineraries);
    } catch (error) {
        console.error('Error fetching itineraries by traveler:', error);
        res.status(500).json({
            error: 'Failed to fetch itineraries',
            message: error.message
        });
    }
});

// Get itinerary by ID
router.get('/:id', async (req, res) => {
    try {
        const itinerary = await Itinerary.findById(req.params.id)
            .populate('travelerId', 'fullName email age gender state')
            .select('-__v');
        
        if (!itinerary) {
            return res.status(404).json({
                error: 'Itinerary not found'
            });
        }

        res.json(itinerary);
    } catch (error) {
        console.error('Error fetching itinerary:', error);
        
        if (error.name === 'CastError') {
            return res.status(400).json({
                error: 'Invalid itinerary ID'
            });
        }

        res.status(500).json({
            error: 'Failed to fetch itinerary',
            message: error.message
        });
    }
});

// Get statistics
router.get('/stats/summary', async (req, res) => {
    try {
        const stats = await Itinerary.getStatistics();
        res.json(stats);
    } catch (error) {
        console.error('Error fetching itinerary statistics:', error);
        res.status(500).json({
            error: 'Failed to fetch statistics',
            message: error.message
        });
    }
});

// Update itinerary
router.put('/:id', async (req, res) => {
    try {
        const itinerary = await Itinerary.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true, runValidators: true }
        ).select('-__v');

        if (!itinerary) {
            return res.status(404).json({
                error: 'Itinerary not found'
            });
        }

        res.json({
            message: 'Itinerary updated successfully',
            itinerary
        });
    } catch (error) {
        console.error('Error updating itinerary:', error);
        
        if (error.name === 'ValidationError') {
            const errors = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({
                error: 'Validation failed',
                details: errors
            });
        }

        res.status(500).json({
            error: 'Failed to update itinerary',
            message: error.message
        });
    }
});

// Delete itinerary
router.delete('/:id', async (req, res) => {
    try {
        const itinerary = await Itinerary.findByIdAndDelete(req.params.id);
        
        if (!itinerary) {
            return res.status(404).json({
                error: 'Itinerary not found'
            });
        }

        res.json({
            message: 'Itinerary deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting itinerary:', error);
        res.status(500).json({
            error: 'Failed to delete itinerary',
            message: error.message
        });
    }
});

module.exports = router;