const mongoose = require('mongoose');

const travelerSchema = new mongoose.Schema({
    fullName: { type: String, required: [true, 'Full name is required'], trim: true },
    age: { type: Number, required: [true, 'Age is required'], min: 12, max: 100 },
    gender: { type: String, required: true, enum: ['male', 'female', 'other', 'prefer-not-to-say'] },
    email: { type: String, required: [true, 'Email is required'], unique: true, lowercase: true },
    phone: { type: String },
    nationality: { type: String },
    state: { type: String, required: true },
    cities: { type: String },
    season: { type: String, required: true },
    duration: { type: Number, required: true },
    budget: { type: String, required: true },
    travelStyle: { type: String, required: true },
    specialRequirements: { type: String },
    companions: [{ type: String }],
    ipAddress: { type: String },
}, { timestamps: true });

// === Statistics Helper ===
travelerSchema.statics.getStatistics = async function() {
    const totalTravelers = await this.countDocuments();

    const byStateAgg = await this.aggregate([
        { $group: { _id: '$state', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
    ]);
    const byState = {};
    byStateAgg.forEach(entry => byState[entry._id] = entry.count);

    const byGenderAgg = await this.aggregate([
        { $group: { _id: '$gender', count: { $sum: 1 } } }
    ]);
    const byGender = {};
    byGenderAgg.forEach(entry => byGender[entry._id] = entry.count);

    return { totalTravelers, byState, byGender };
};

module.exports = mongoose.model('Traveler', travelerSchema);
