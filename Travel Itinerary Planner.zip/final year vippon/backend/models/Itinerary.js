const mongoose = require('mongoose');

const itinerarySchema = new mongoose.Schema({
    travelerId: { type: mongoose.Schema.Types.ObjectId, ref: 'Traveler', required: true },
    state: { type: String, required: true },
    duration: { type: Number, required: true },
    travelStyle: { type: String, required: true },
    budget: { type: String, required: true },
    itineraryContent: { type: String, required: true },
    generatedAt: { type: Date, default: Date.now }
}, { timestamps: true });

// === Statistics Helper ===
itinerarySchema.statics.getStatistics = async function() {
    const totalItineraries = await this.countDocuments();

    const byStateAgg = await this.aggregate([
        { $group: { _id: '$state', count: { $sum: 1 } } },
        { $sort: { count: -1 } }
    ]);
    const byState = {};
    byStateAgg.forEach(entry => byState[entry._id] = entry.count);

    const byBudgetAgg = await this.aggregate([
        { $group: { _id: '$budget', count: { $sum: 1 } } }
    ]);
    const byBudget = {};
    byBudgetAgg.forEach(entry => byBudget[entry._id] = entry.count);

    return { totalItineraries, byState, byBudget };
};

module.exports = mongoose.model('Itinerary', itinerarySchema);
