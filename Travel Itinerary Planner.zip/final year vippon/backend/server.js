const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./config/db');

// Load environment variables
dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
connectDB();

// Import routes
const travelerRoutes = require('./routes/travelers');
const itineraryRoutes = require('./routes/itineraries');

// Use routes
app.use('/api/travelers', require('./routes/travelers'));
app.use('/api/itineraries', require('./routes/itineraries'));


// Serve frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// ✅ FIX for Express 5 (avoid wildcard errors)
app.use((req, res) => {
  res.sendFile(path.join(__dirname, '../frontend', 'index.html'));
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🌍 Welcome to India Travel Planner Backend`);
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
